from cyclecloud import session as _session
from cyclecloud import model as _model
from cyclecloud.api import clusters as _clusters
from cyclecloud.model.NodeManagementRequestModule import NodeManagementRequest as _NodeManagementRequest
from requests.structures import CaseInsensitiveDict as _CaseInsensitiveDict


class Client(object):
    def __init__(self, config=None, **kwargs):
        self._session = _session.Session(config, **kwargs)
        self._clusters_manager = None

    @property
    def session(self):
        return self._session

    @property
    def clusters(self):
        if self._clusters_manager is None:
            self._clusters_manager = _ClustersManager(self)
        return self._clusters_manager


class _ClustersManager(object):
    def __init__(self, client):
        self._client = client

    def get(self, key):
        return Cluster(self._client, key)

    def __getitem__(self, key):
        return self.get(key)


class Cluster(object):
    def __init__(self, client, name):
        self._client = client
        self._name = name
        self._nodes_manager = None

    @property
    def name(self):
        return self._name

    @property
    def nodes(self):
        return self.get_nodes()

    def get_nodes(self, operation_id=None):
        return _NodesManager(self._client, self._name, operation=operation_id)

    def get_usage(self, timeframe=None, from_time=None, to_time=None, granularity=None):
        _, s = _clusters.get_cluster_usage(
            self._client.session,
            self._name,
            timeframe=timeframe,
            az_from=from_time,
            to=to_time,
            granularity=granularity,
        )

        return s

    def get_status(self, nodes=False):
        _, s = _clusters.get_cluster_status(self._client.session, self._name, nodes=nodes)

        for nodearray in s.nodearrays:
            nodearray.nodearray = Record(nodearray.nodearray)

        if s.nodes:
            s.nodes = [Record(i) for i in s.nodes]

        return s

    def scale_by_cores(self, nodearray, total_core_count):
        _, s = _clusters.scale(self._client.session, self._name, nodearray, total_core_count=total_core_count)
        return s

    def scale_by_nodes(self, nodearray, total_node_count):
        _, s = _clusters.scale(self._client.session, self._name, nodearray, total_node_count=total_node_count)
        return s

    def start_nodes(
        self,
        names=None,
        ids=None,
        hostnames=None,
        ip_addresses=None,
        filter=None,
    ):
        request = self._node_management_request(
            filter=filter,
            hostnames=hostnames,
            ids=ids,
            ip_addresses=ip_addresses,
            names=names
        )
        return _clusters.start_nodes(
            self._client.session, self._name, request
        )

    def deallocate_nodes(
        self,
        names=None,
        ids=None,
        hostnames=None,
        ip_addresses=None,
        filter=None,
    ):
        request = self._node_management_request(
            filter=filter,
            hostnames=hostnames,
            ids=ids,
            ip_addresses=ip_addresses,
            names=names
        )
        return _clusters.deallocate_nodes(
            self._client.session, self._name, request
        )

    def shutdown_nodes(
        self,
        names=None,
        ids=None,
        hostnames=None,
        ip_addresses=None,
        filter=None,
    ):
        request = self._node_management_request(
            filter=filter,
            hostnames=hostnames,
            ids=ids,
            ip_addresses=ip_addresses,
            names=names
        )
        return _clusters.shutdown_nodes(
            self._client.session, self._name, request
        )

    def terminate_nodes(
        self,
        names=None,
        ids=None,
        hostnames=None,
        ip_addresses=None,
        filter=None,
    ):
        request = self._node_management_request(
            filter=filter,
            hostnames=hostnames,
            ids=ids,
            ip_addresses=ip_addresses,
            names=names
        )
        return _clusters.terminate_nodes(
            self._client.session, self._name, request
        )

    def _node_management_request(
        self,
        filter=None,
        hostnames=None,
        ids=None,
        ip_addresses=None,
        names=None,
        request_id=None
    ):
        request = _NodeManagementRequest()

        if filter:
            request.filter = filter

        if hostnames:
            request.hostnames = hostnames

        if ids:
            request.ids = ids

        if ip_addresses:
            request.ip_addresses = ip_addresses

        if names:
            request.names = names

        if request_id:
            request.request_id = request_id

        request.validate()

        return request


class _NodesManager(object):
    def __init__(self, client, cluster_name, operation=None):
        self._client = client
        self._cluster_name = cluster_name
        self._operation = operation
        self._pos = 0
        self._raw_list = None

    @property
    def _node_list(self):
        if self._raw_list is None:
            _, self._raw_list = _clusters.get_nodes(self._client.session, self._cluster_name, self._operation)
        return self._raw_list

    def __len__(self):
        return len(self._node_list.nodes)

    def __iter__(self):
        self._pos = 0
        return self

    def next(self):
        return self.__next__()

    def __next__(self):
        if self._pos < len(self._node_list.nodes):
            n = self._node_list.nodes[self._pos]
            self._pos += 1
            return Record(n)
        else:
            raise StopIteration


class Record(_CaseInsensitiveDict):
    def __init__(self, data=None, **kwargs):
        super(Record, self).__init__(data=data, **kwargs)

        for k in self:
            if isinstance(self[k], dict):
                self[k] = Record(self[k])

            elif isinstance(self[k], list):
                new_list = []
                for i in self[k]:
                    if isinstance(i, dict):
                        i = Record(i)
                    new_list.append(i)
                self[k] = new_list

    def to_dict(self):
        d = dict(self)
        for k in d:
            d[k] = Record._recurse_to_dict(d[k])

        return d

    @staticmethod
    def _recurse_to_dict(value):
        if isinstance(value, Record):
            return value.to_dict()

        elif isinstance(value, list):
            return [Record._recurse_to_dict(i) for i in value]

        elif isinstance(value, dict):
            return {k: Record._recurse_to_dict(value[k]) for k in value}

        return value

    @staticmethod
    def from_dict(dict_obj):
        return Record(dict_obj)
