# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import copy as _copy
import json as _json

from cyclecloud import model as _model


_TAG="Clusters"

class _RequestContext(object):
    def __init__(self):
        self.url = None
        self.host = None
        self.path = None
        self.tag = None
        self.operation = None


def get_nodes(session, cluster, operation=None, request_id=None):
    """
    No description available
    Parameters:
    cluster: string, The cluster to query, Required
    operation: string, If given, returns only the nodes for this operation ID, and includes the operation attribute on the body 
, Optional
    request_id: string, If given, returns only the nodes for the operation identified by this request ID, and includes the operation attribute on the body 
, Optional

    Returns: (status, data)
    (200, NodeList)
    (400, async_url)
    (404, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "getNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes".format(**_path_parameters)

    _query = {}
    if operation:
        _query['operation'] = operation
    if request_id:
        _query['request_id'] = request_id

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'object', _model.NodeList.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def create_nodes(session, cluster, nodes):
    """
    This operation adds new nodes from a nodearray to a cluster. It accepts multiple node definitions in a single call. It returns the URL to the operation that can be used to track the status of the operation.

    Parameters:
    cluster: string, The cluster to add nodes to, Required
    nodes: NodeCreationRequest, Sets of nodes to be created, Required

    Returns: (status, data)
    (202, NodeCreationResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not nodes:
        raise ValueError('nodes is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "createNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/create".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(nodes) is dict:
        _body = _json.dumps(nodes)
    else:
        _body = nodes.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeCreationResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def deallocate_nodes(session, cluster, action):
    """
    This operation deallocates nodes in a cluster. The nodes can be identified in several ways,  including node name, node ID, or by filter.

    Parameters:
    cluster: string, The cluster to deallocate nodes in, Required
    action: NodeManagementRequest, Description of which nodes to deallocate, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "deallocateNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/deallocate".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def reimage_nodes(session, cluster, action):
    """
    This operation reimages nodes in a cluster. The nodes can be identified in several ways,  including node name, node ID, or by filter.

    Parameters:
    cluster: string, The cluster to reimage nodes in, Required
    action: NodeManagementRequest, Description of which nodes to reimage, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "reimageNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/reimage".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def remove_nodes(session, cluster, action):
    """
    This operation removes nodes in a cluster. You can identify the nodes by node name, node ID, or filter. By default, CycleCloud removes nodes on termination, so this call behaves like terminate. Nodes with the Fixed attribute set to true aren't removed on termination.

    Parameters:
    cluster: string, The cluster to remove nodes in, Required
    action: NodeManagementRequest, Description of which nodes to remove, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "removeNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/remove".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def restart_nodes(session, cluster, action):
    """
    This operation restarts nodes in a cluster. The nodes can be identified in several ways,  including node name, node ID, or by filter.

    Parameters:
    cluster: string, The cluster to restart nodes in, Required
    action: NodeManagementRequest, Description of which nodes to restart, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "restartNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/restart".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def shutdown_nodes(session, cluster, action):
    """
    This call shuts down nodes in a cluster. Each node's ShutdownPolicy attribute decides the action: Terminate (default) or Deallocate.

    Parameters:
    cluster: string, The cluster to shut down nodes in, Required
    action: NodeManagementRequest, Description of which nodes to shut down, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "shutdownNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/shutdown".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def start_nodes(session, cluster, action):
    """
    This operation starts nodes in a cluster. The nodes can be identified in several ways,  including node name, node ID, or by filter.

    Parameters:
    cluster: string, The cluster to start nodes in, Required
    action: NodeManagementRequest, Description of which nodes to start, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "startNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/start".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def terminate_nodes(session, cluster, action):
    """
    This operation terminates nodes in a cluster. The nodes can be identified in several ways,  including node name, node ID, or by filter.

    Parameters:
    cluster: string, The cluster to terminate nodes in, Required
    action: NodeManagementRequest, Description of which nodes to terminate, Required

    Returns: (status, data)
    (202, NodeManagementResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not action:
        raise ValueError('action is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "terminateNodes"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/nodes/terminate".format(**_path_parameters)

    _query = {}

    _headers = {}

    _body = None
    if type(action) is dict:
        _body = _json.dumps(action)
    else:
        _body = action.json_encode()

    _responses = []
    _responses.append((202, 'object', _model.NodeManagementResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def get_ghr(session, cluster, node, category=None, description=None):
    """
    Returns the workload impact of a node with a health issue, so you can submit it to the health reporting endpoint.
    Parameters:
    cluster: string, The cluster that contains the node to report, Required
    node: string, The node to report, Required
    category: string, Guest Health Report category for the impact, Optional
    description: string, Custom message describing the failure or context, Optional

    Returns: (status, data)
    (200, async_url)
    (400, async_url)
    (404, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not node:
        raise ValueError('node is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "getGHR"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _path_parameters["node"] = node
    _request_context.path = "/clusters/{cluster}/nodes/{node}/ghr".format(**_path_parameters)

    _query = {}
    if category:
        _query['category'] = category
    if description:
        _query['description'] = description

    _headers = {}

    _body = None

    _responses = []

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def ghr_node(session, cluster, node, category=None, description=None):
    """
    Submit a health report for a node with a health issue
    Parameters:
    cluster: string, The cluster that contains the node to report, Required
    node: string, The node to report, Required
    category: string, Guest Health Report category for the impact, Optional
    description: string, Custom message describing the failure or context, Optional

    Returns: (status, data)
    (202, async_url)
    (400, async_url)
    (404, async_url)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not node:
        raise ValueError('node is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "gHRNode"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _path_parameters["node"] = node
    _request_context.path = "/clusters/{cluster}/nodes/{node}/ghr".format(**_path_parameters)

    _query = {}
    if category:
        _query['category'] = category
    if description:
        _query['description'] = description

    _headers = {}

    _body = None

    _responses = []

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def scale(session, cluster, nodearray, total_core_count=None, total_node_count=None):
    """
    This operation adds nodes as needed to a nodearray to hit a total count. The request is processed one time and doesn't re-add nodes later to maintain the given number. Specify the target size using either `totalCoreCount` (total CPU cores) or `totalNodeCount` (total VMs), but not both in the same request. It returns the URL to the operation that you can use to track its status.

    Parameters:
    cluster: string, The cluster to add nodes to, Required
    nodearray: string, The nodearray to add nodes to, Required
    total_core_count: integer, The total number of cores to have in this nodearray, including nodes already created
, Optional
    total_node_count: integer, The total number of machines to have in this nodearray, including nodes already created
, Optional

    Returns: (status, data)
    (202, NodeCreationResult)
    (409, async_url)
    """
    if not cluster:
        raise ValueError('cluster is required.')
    if not nodearray:
        raise ValueError('nodearray is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "scale"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _path_parameters["nodearray"] = nodearray
    _request_context.path = "/clusters/{cluster}/scale/{nodearray}".format(**_path_parameters)

    _query = {}
    if total_core_count:
        _query['totalCoreCount'] = total_core_count
    if total_node_count:
        _query['totalNodeCount'] = total_node_count

    _headers = {}

    _body = None

    _responses = []
    _responses.append((202, 'object', _model.NodeCreationResult.from_dict))

    _status, _response = session.request(_request_context, 'POST', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def get_cluster_status(session, cluster, nodes=None):
    """
    This operation contains information for the nodes and nodearrays in a given cluster. For each nodearray, it returns the status of each available allocation "bucket". The status includes the current node count in the bucket and how many more nodes you can add. Each bucket is a set of possible VMs of a given hardware profile that can be created in a given location under a given customer account, etc. The user's cluster definition determines the valid buckets for a nodearray, but the cloud provider partly determines the limits.

    Parameters:
    cluster: string, The cluster to query, Required
    nodes: boolean, If true, nodes and node references are returned in the response, Optional

    Returns: (status, data)
    (200, ClusterStatus)
    """
    if not cluster:
        raise ValueError('cluster is required.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "getClusterStatus"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/status".format(**_path_parameters)

    _query = {}
    if nodes:
        _query['nodes'] = str(nodes).lower()

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'object', _model.ClusterStatus.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


def get_cluster_usage(session, cluster, timeframe=None, az_from=None, to=None, granularity=None):
    """
    This operation returns overall usage data (core hours) and cost data, if available, for the cluster, and a per-nodearray breakdown. By default it returns the current month's worth of usage.

    Parameters:
    cluster: string, The cluster to return usage data for, Required
    timeframe: ['monthToDate', 'lastMonth', 'weekToDate', 'custom'], The time range to use for the query. Valid values: `monthToDate` (current month), `lastMonth` (previous month), `weekToDate` (current week, starting Sunday), or `custom` (requires the `from` and `to` query parameters). The default is `monthToDate`. All times are in UTC.
, Optional
    az_from: string, For custom timeframes, this value is the start of the timeframe in ISO-8601 format. It is rounded down to the nearest hour or day.
, Optional
    to: string, For custom timeframes, this value is the end of the timeframe in ISO-8601 format. It is rounded up to the nearest hour or day.
, Optional
    granularity: ['total', 'daily', 'hourly'], Specifies how to aggregate data: hourly, daily, or as a single total. The default interval is daily.
, Optional

    Returns: (status, data)
    (200, ClusterUsage)
    """
    _valid_timeframe = ["monthToDate", "lastMonth", "weekToDate", "custom"]
    _valid_granularity = ["total", "daily", "hourly"]
    if not cluster:
        raise ValueError('cluster is required.')
    if timeframe:
        if timeframe.lower() not in (val.lower() for val in _valid_timeframe):
            raise ValueError('Invalid value specified for timeframe.')
    if granularity:
        if granularity.lower() not in (val.lower() for val in _valid_granularity):
            raise ValueError('Invalid value specified for granularity.')

    _request_context = _RequestContext()
    _request_context.tag = _TAG
    _request_context.operation = "getClusterUsage"

    _path_parameters = {}
    _path_parameters["cluster"] = cluster
    _request_context.path = "/clusters/{cluster}/usage".format(**_path_parameters)

    _query = {}
    if timeframe:
        _query['timeframe'] = timeframe
    if az_from:
        _query['from'] = az_from
    if to:
        _query['to'] = to
    if granularity:
        _query['granularity'] = granularity

    _headers = {}

    _body = None

    _responses = []
    _responses.append((200, 'object', _model.ClusterUsage.from_dict))

    _status, _response = session.request(_request_context, 'GET', query=_query, headers=_headers, body=_body, expected_responses=_responses)
    return _status, _response


