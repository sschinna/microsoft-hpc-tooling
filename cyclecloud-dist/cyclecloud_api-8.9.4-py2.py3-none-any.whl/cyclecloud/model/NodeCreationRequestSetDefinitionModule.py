# -*- coding: utf-8 -*-
#
# Generated Code - Do Not Edit
#


import json
import platform
import six

__IS_JYTHON__ = platform.system().lower() == "java"


if __IS_JYTHON__:
    from com.microsoft.cyclecloud.model import NodeCreationRequestSetDefinition as _NodeCreationRequestSetDefinition


    def json_decode(json_string):
        return _NodeCreationRequestSetDefinition.json_decode(json_string)


    def from_dict(dict_obj):
        return _NodeCreationRequestSetDefinition.from_dict(dict_obj)


    def NodeCreationRequestSetDefinition(**kwargs):
        obj = _NodeCreationRequestSetDefinition()
        for k, v in six.iteritems(kwargs):
            setattr(obj, k, v)
        return obj


    NodeCreationRequestSetDefinition.json_decode = _NodeCreationRequestSetDefinition.json_decode
    NodeCreationRequestSetDefinition.from_dict = _NodeCreationRequestSetDefinition.from_dict


else:


    def json_decode(json_string):
        return NodeCreationRequestSetDefinition.json_decode(json_string)


    def from_dict(dict_obj):
        return NodeCreationRequestSetDefinition.from_dict(dict_obj)


    class NodeCreationRequestSetDefinition(object):
        """
        The definition of the bucket to use, provided by the cluster status API call. If some of the items given in the status call are missing, or the entire bucket property is missing, the first bucket that matches the given items is used.

        machine_type: string, , Optional
        """

        def __init__(self, **kwargs):
            self.machine_type = kwargs.get('machine_type')

        def validate(self):
            """
            Verify that all required properties are set.
            """
            pass

        def to_dict(self):
            """
            Creates a dict representation of the object.
            """
            dict_obj = {}
            if self.machine_type is not None:
                dict_obj["machineType"] = self.machine_type

            return dict_obj

        def json_encode(self):
            return json.dumps(self, default=lambda x: x if type(x) is dict else x.to_dict())

        @staticmethod
        def from_dict(dict_obj):
            """
            Static initializer to create an instance from a dictionary.
            """
            if dict_obj is None:
                return None

            # Convert dictionary keys to lowercase
            dict_obj = dict((k.lower(), v) for k, v in six.iteritems(dict_obj))

            obj = NodeCreationRequestSetDefinition()

            value = dict_obj.get('machinetype')
            if value is not None:
                obj.machine_type = value

            return obj

        @staticmethod
        def json_decode(json_string):
            """
            Static initializer to create an instance from a json string.
            """
            dict_obj = json.loads(json_string)
            return NodeCreationRequestSetDefinition.from_dict(dict_obj)

        def __eq__(self, other):
            if not hasattr(other, "to_dict"):
                return False
            return self.to_dict() == other.to_dict()

        @property
        def machine_type(self):
            """
            machine_type: string, , Optional
            """
            return self._machine_type

        @machine_type.setter
        def machine_type(self, value):
            """
            machine_type: string, , Optional
            """
            self._machine_type = value

