import copy
import json
import urllib3
import requests
from requests.exceptions import ConnectionError
from cyclecloud.version import __version__
from cyclecloud import config as _ccapi_config


class ResponseStatus(object):
    def __init__(self, r):
        self.status_code = r.status_code
        self.headers = copy.deepcopy(r.headers)


class Session(object):
    def __init__(self, config=None, **kwargs):
        if config is None and not kwargs:
            config = _ccapi_config.get_config().get("cyclecloud")

        if config is None:
            config = {}
        config.update(kwargs)

        self._config = copy.deepcopy(config)
        self._session = None

        for r in ["url", "username", "password"]:
            if r not in self._config:
                raise ValueError("No value given for '%s'." % r)

        self._config["timeout"] = int(self._config.get("timeout", 60))
        self._config["verify_certificates"] = str(self._config.get("verify_certificates", True)).lower() in ["true"]

    def _request(self, verb, full_url, query, headers, body):
        if self._session is None:
            self._session = Session._get_session(self._config)
        try:
            return self._session.request(verb, full_url, params=query, headers=headers, data=body, timeout=self._config["timeout"])
        except ConnectionError as e:
            raise Exception("Unable to connect to %s - %s" % (self._config["url"], e))

    def request(self, request_context, verb, query, headers, body, expected_responses):
        base_url = self._config["url"]
        base_url = base_url.rstrip("/")
        if not request_context.path.startswith("/"):
            base_url += "/"
        full_url = base_url + request_context.path

        r = self._request(verb, full_url, query, headers, body)

        if r.status_code == 401:
            raise Exception("Invalid username or password for %s" % base_url)

        if 400 <= r.status_code < 600:
            if r.text:
                raise Exception(r.text)
            else:
                raise Exception("Unspecified Error (%s)" % r.status_code)

        status = ResponseStatus(r)
        response = r.text

        if response:
            response = json.loads(response)

            for status_code, object_type, constructor in expected_responses:

                if r.status_code == status_code:
                    if object_type == 'object':
                        response = constructor(response)

                    elif object_type == 'array':
                        _ary = []
                        for item in response:
                            _ary.append(constructor(item))
                        response = _ary

                    elif object_type == 'map':
                        _map = {}
                        for key, value in response.iteritems():
                            _map[key] = constructor(value)
                        response = _map

                    break

        return status, response

    @staticmethod
    def _get_session(config):
        verify_certificates = config["verify_certificates"]
        if not verify_certificates:
            urllib3.disable_warnings()

        s = requests.session()
        s.auth = (config["username"], config["password"])
        s.timeout = config["timeout"]
        s.verify = verify_certificates
        s.headers = {"X-Cycle-Client-Version": "cyclecloud-python-api:%s" % __version__,
                     "User-Agent": "CycleCloudPythonApi/%s" % __version__}

        return s
